/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.testepessoa;

/**
 *
 * @author dti
 */
public class Professor extends Pessoa {
    String formação;
    
    public void DefinirFormação(){
        System.out.println("DS, PW, FI, SE.");
    
    }
    public void RetornarIdade(){
    
    }

    
}

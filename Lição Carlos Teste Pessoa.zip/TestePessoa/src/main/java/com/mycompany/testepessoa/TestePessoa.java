/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.testepessoa;

/**
 *
 * @author dti
 */
public class TestePessoa  extends Pessoa{

    public static void main(String[] args) {
        Pessoa pess = new Pessoa();
        
        Aluno aluno = new Aluno();
        
        Professor prof = new Professor();
        prof.DefinirFormação();
        aluno.DefinirCurso();
        
       
    }
}

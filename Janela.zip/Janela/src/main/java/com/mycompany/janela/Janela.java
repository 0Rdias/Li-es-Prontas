/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.janela;
import javax.swing.*;
import java.awt.*;

public class Janela extends JFrame {
    JLabel rot1,rot2;
    JTextField txt1,txt2;
    JButton add,sub,div,mult,sqr,cub,root,rslt;
    public Janela(){
        super ("Primeira Janela");
            Container tela = getContentPane();
            setLayout(null);
        setSize(350, 200);
        setVisible(true);
        setLocationRelativeTo(null);
        setResizable(false);
      
        //_______________________________________________________
        
        rot1 = new JLabel("1° Número");
        rot2 = new JLabel("2° Número");
        txt1 = new JTextField(15);
        txt2 = new JTextField(15);
        rot1.setBounds(10, 10, 60, 20);
        rot2.setBounds(10, 40, 60, 20);
        rot1.setForeground(Color.black);
        rot2.setForeground(Color.black);
        txt1.setBounds(100,40,150,25);
        txt2.setBounds(100,10,150,25);
        
        
        tela.add(rot1);
        tela.add(rot2);
        tela.add(txt1);
        tela.add(txt2);
        
        
    }
        public static void main(String[] args) {
            Janela app = new Janela();
           app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    }


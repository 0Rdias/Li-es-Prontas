/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exemplodecarro;

/**
 *
 * @author dti
 */
public class Exemplodecarro {

    public static void main(String[] args) {
        //Criando objeto (instância da classe Carro
        Carro carrin = new Carro();
        //Atribuindo os valores dos atributos do carro
        carrin.modelo = "Opala";
        carrin.cor = "marrom";
        carrin.motor = "4 cil.";
        //executando os métodos do objeto
        System.out.println("opala");
        System.out.println("marrom");
        System.out.println("4 cil.");
        carrin.ligar();
        carrin.acelerar();
        carrin.mudarMarcha();
        carrin.frear();
        carrin.desligar();
        carrin = null;
    }
}

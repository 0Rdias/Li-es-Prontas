/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javacarlos;
import javax.swing.*;
import java.awt.*;
public class JavaCarlos extends JFrame {
    JLabel rot1, rot2, rot3, rot4;
    JTextField txt1, txt2, txt3, txt4;
    public JavaCarlos(){
    super ("exemplo com JTextField");
    Container tela = getContentPane();
    setLayout(null);
    rot1 = new JLabel ("Nome");
    rot2 = new JLabel ("Idade");
    rot3 = new JLabel ("Telefone"); 
    rot4 = new JLabel ("Celular");  
    
    txt1 = new JTextField (50);
    txt2 = new JTextField (3);
    txt3 = new JTextField (10);
    txt4 = new JTextField (10);
    
    rot1.setBounds(50,20,80,20);
    rot2.setBounds(50,60,80,20);
    rot3.setBounds(50,100,80,20);
    rot4.setBounds(50,140,80,20);
    
    txt1.setBounds (110,20,200,20);
    txt2.setBounds (110,60,20,20);
    txt3.setBounds (110,100,80,20);
    txt4.setBounds (110,140,80,20);
    
    tela.add(rot1);
    tela.add(rot2);
    tela.add(rot3);
    tela.add(rot4);
    tela.add(txt1);
    tela.add(txt2);
    tela.add(txt3);
    tela.add(txt4);
    setSize (400,250);
    setVisible (true);
    setLocationRelativeTo(null);
    
    }
    public static void main(String[] args) {
        JavaCarlos app = new JavaCarlos();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
